#define _USE_MATH_DEFINES
#include <cmath>
#include <stdio.h>

int main(){
    printf("%lf", std::riemann_zeta(M_PI));
}


// Mail with the output to get 10 marks bonus in any one group assignment
// Open for first 10 teams 