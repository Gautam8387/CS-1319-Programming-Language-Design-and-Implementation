extern int yyparse();

int main(){
    yyparse();
}